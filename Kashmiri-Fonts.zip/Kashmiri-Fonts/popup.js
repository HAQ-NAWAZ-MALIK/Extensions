const fontSelect = document.getElementById('fontSelect');
const fontPreview = document.getElementById('fontPreview');
const applyFontBtn = document.getElementById('applyFontBtn');
const errorMsg = document.getElementById('errorMsg');
const extensionToggle = document.getElementById('extensionToggle');
const toggleLabel = document.getElementById('toggleLabel');
const applyScopeRadios = document.getElementsByName('applyScope');

const bundledFonts = [
  { name: 'Afan Koshur Naksh', file: 'Afan_Koshur_Naksh.ttf' },
  { name: 'Gulmarg Nastaleeq', file: 'Gulmarg Nastaleeq-8.11.2013.ttf' },
  { name: 'Nakash (Narqalam)', file: 'Nakash (Narqalam).ttf' }
];

function populateFonts() {
  fontSelect.innerHTML = '';
  bundledFonts.forEach(font => {
    const option = document.createElement('option');
    option.value = font.file;
    option.textContent = font.name;
    fontSelect.appendChild(option);
  });
}

function updatePreview() {
  const selectedFont = fontSelect.value;
  const fontName = bundledFonts.find(f => f.file === selectedFont)?.name || 'Kashmiri Font';
  const fontUrl = chrome.runtime.getURL('fonts/' + selectedFont);
  const styleId = 'preview-font-style';
  let style = document.getElementById(styleId);
  if (style) style.remove();
  style = document.createElement('style');
  style.id = styleId;
  style.textContent = `@font-face { font-family: '${fontName}'; src: url('${fontUrl}'); }\n    #fontPreview { font-family: '${fontName}', sans-serif; }`;
  document.head.appendChild(style);
  fontPreview.style.fontFamily = `'${fontName}', sans-serif`;
}

function getSelectedScope() {
  for (const radio of applyScopeRadios) {
    if (radio.checked) return radio.value;
  }
  return 'page';
}

function setSelectedScope(scope) {
  for (const radio of applyScopeRadios) {
    radio.checked = (radio.value === scope);
  }
}

function setToggleState(isOn) {
  extensionToggle.checked = isOn;
  toggleLabel.textContent = isOn ? 'Extension On' : 'Extension Off';
}

fontSelect.addEventListener('change', () => {
  updatePreview();
  errorMsg.textContent = '';
});

extensionToggle.addEventListener('change', () => {
  const isOn = extensionToggle.checked;
  setToggleState(isOn);
  chrome.storage.sync.set({ kf_enabled: isOn });
  // Optionally, re-apply or remove font on all tabs if global
  if (!isOn) {
    // Remove font from all tabs if off
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, { type: 'REMOVE_FONT' });
      });
    });
  } else {
    // If on and global, re-apply font
    chrome.storage.sync.get(['kf_font', 'kf_scope'], (data) => {
      if (data.kf_scope === 'global') {
        applyFontToAllTabs(data.kf_font);
      }
    });
  }
});

applyFontBtn.addEventListener('click', () => {
  const selectedFont = fontSelect.value;
  const fontName = bundledFonts.find(f => f.file === selectedFont)?.name || 'Kashmiri Font';
  const fontUrl = chrome.runtime.getURL('fonts/' + selectedFont);
  const scope = getSelectedScope();
  const isOn = extensionToggle.checked;
  // Save settings
  chrome.storage.sync.set({ kf_font: selectedFont, kf_scope: scope, kf_enabled: isOn });
  if (!isOn) {
    errorMsg.textContent = 'Extension is off.';
    return;
  }
  if (scope === 'global') {
    applyFontToAllTabs(selectedFont);
  } else {
    // Apply only to current tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(
        tabs[0].id,
        { type: 'APPLY_FONT', fontName, fontUrl },
        (response) => {
          if (!response || !response.success) {
            errorMsg.textContent = response?.error || 'Failed to apply font.';
          } else {
            errorMsg.textContent = '';
          }
        }
      );
    });
  }
});

function applyFontToAllTabs(selectedFont) {
  const fontName = bundledFonts.find(f => f.file === selectedFont)?.name || 'Kashmiri Font';
  const fontUrl = chrome.runtime.getURL('fonts/' + selectedFont);
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, { type: 'APPLY_FONT', fontName, fontUrl });
    });
  });
}

// Restore settings on load
function restoreSettings() {
  chrome.storage.sync.get(['kf_font', 'kf_scope', 'kf_enabled'], (data) => {
    if (data.kf_font) fontSelect.value = data.kf_font;
    if (data.kf_scope) setSelectedScope(data.kf_scope);
    setToggleState(data.kf_enabled !== false); // default ON
    updatePreview();
  });
}

// Listen for radio changes to save scope
applyScopeRadios.forEach(radio => {
  radio.addEventListener('change', () => {
    chrome.storage.sync.set({ kf_scope: getSelectedScope() });
  });
});

populateFonts();
restoreSettings(); 