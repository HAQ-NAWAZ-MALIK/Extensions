document.addEventListener('DOMContentLoaded', function () {
    const toggleBtn = document.getElementById('toggleBtn');
    const statusLight = document.getElementById('statusLight');
    const statusText = document.getElementById('statusText');
    const openGuideBtn = document.getElementById('openGuideBtn');
    const toggleKeyboardGuideBtn = document.getElementById('toggleKeyboardGuideBtn');
    const fontSizeSlider = document.getElementById('fontSize');
    const fontSizeValue = document.getElementById('fontSizeValue');
    const fontFamilySelect = document.getElementById('fontFamily');
    const showRealTimeKeyboard = document.getElementById('showRealTimeKeyboard');

    // Default settings
    const defaultSettings = {
        fontSize: 16,
        fontFamily: 'Noto Nastaliq Urdu',
        isGuideVisible: false,
        showRealTimeKeyboard: false
    };

    // Load current state and settings
    chrome.storage.sync.get(['isEnabled', 'settings'], function (data) {
        const isEnabled = data.isEnabled || false;
        console.log('Current extension state:', isEnabled ? 'ON' : 'OFF');
        updateUI(isEnabled);

        // Load settings
        const settings = data.settings || defaultSettings;
        updateSettingsUI(settings);
    });

    // Toggle extension state
    toggleBtn.addEventListener('click', function () {
        chrome.storage.sync.get('isEnabled', function (data) {
            const newState = !(data.isEnabled || false);
            console.log('Toggling extension state to:', newState ? 'ON' : 'OFF');

            // Save new state
            chrome.storage.sync.set({ isEnabled: newState }, function () {
                updateUI(newState);

                // Notify background script to update icon
                chrome.runtime.sendMessage({ action: 'updateIcon', isEnabled: newState });

                // Notify content script about the state change
                chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                    if (tabs[0]) {
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: 'stateChanged',
                            isEnabled: newState
                        });
                        console.log('Sent state change message to tab:', tabs[0].id);
                    }
                });

                // Show notification in the current tab
                showNotificationInTab(newState);
            });
        });
    });

    // Open guide in new tab
    openGuideBtn.addEventListener('click', function () {
        chrome.tabs.create({ url: chrome.runtime.getURL('guide.html') });
    });

    // Toggle keyboard guide visibility
    toggleKeyboardGuideBtn.addEventListener('click', function () {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'toggleKeyboardGuide'
                });
            }
        });
    });

    // Font size change handler
    fontSizeSlider.addEventListener('input', function () {
        const newSize = this.value;
        fontSizeValue.textContent = `${newSize}px`;

        // Update stored settings
        updateSettings({
            fontSize: parseInt(newSize, 10)
        });
    });

    // Font family change handler
    fontFamilySelect.addEventListener('change', function () {
        updateSettings({
            fontFamily: this.value
        });
    });

    // Real-time keyboard toggle handler
    showRealTimeKeyboard.addEventListener('change', function () {
        updateSettings({
            showRealTimeKeyboard: this.checked
        });
    });

    function updateUI(isEnabled) {
        if (isEnabled) {
            statusLight.classList.add('active');
            statusText.textContent = 'ON';
            toggleBtn.textContent = 'Disable Keyboard';
            toggleBtn.classList.add('active');
        } else {
            statusLight.classList.remove('active');
            statusText.textContent = 'OFF';
            toggleBtn.textContent = 'Enable Keyboard';
            toggleBtn.classList.remove('active');
        }
    }

    function updateSettingsUI(settings) {
        // Update font size slider and display
        fontSizeSlider.value = settings.fontSize;
        fontSizeValue.textContent = `${settings.fontSize}px`;

        // Update font family select - directly set the value
        fontFamilySelect.value = settings.fontFamily || 'Noto Nastaliq Urdu';

        // Update real-time keyboard toggle
        showRealTimeKeyboard.checked = settings.showRealTimeKeyboard || false;
    }

    function updateSettings(partialSettings) {
        chrome.storage.sync.get('settings', function (data) {
            const currentSettings = data.settings || defaultSettings;
            const newSettings = { ...currentSettings, ...partialSettings };

            chrome.storage.sync.set({ settings: newSettings }, function () {
                console.log('Settings updated:', newSettings);

                // Notify content script about the settings change
                chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                    if (tabs[0]) {
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: 'settingsChanged',
                            settings: newSettings
                        });
                    }
                });
            });
        });
    }

    function showNotificationInTab(isEnabled) {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'showNotification',
                    text: isEnabled ? 'Kashmiri Keyboard Enabled' : 'Kashmiri Keyboard Disabled',
                    type: isEnabled ? 'success' : 'info'
                });
                console.log('Sent notification message to tab:', tabs[0].id);
            }
        });
    }
});
