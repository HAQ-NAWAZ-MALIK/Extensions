@echo off
echo Packaging Kashmiri Anywhere Keyboard extension...

REM Get version from manifest.json (requires PowerShell)
for /f "tokens=*" %%a in ('powershell -Command "(Get-Content -Raw -Path 'manifest.json' | ConvertFrom-Json).version"') do set VERSION=%%a

set PACKAGE_NAME=kashmiri-anywhere-keyboard
set OUTPUT_ZIP=%PACKAGE_NAME%-v%VERSION%.zip

REM Create temporary directory
if exist temp_package rmdir /s /q temp_package
mkdir temp_package

REM Copy files
copy manifest.json temp_package\
copy popup.html temp_package\
copy popup.css temp_package\
copy popup.js temp_package\
copy background.js temp_package\
copy content.js temp_package\
copy content.css temp_package\
copy guide.html temp_package\
xcopy /E /I images temp_package\images

REM Create ZIP file (requires PowerShell)
if exist %OUTPUT_ZIP% del %OUTPUT_ZIP%
powershell -Command "Compress-Archive -Path 'temp_package\*' -DestinationPath '%OUTPUT_ZIP%'"

REM Clean up
rmdir /s /q temp_package

echo Package created: %OUTPUT_ZIP%
echo You can upload this file to the Chrome Web Store Developer Dashboard.
pause
