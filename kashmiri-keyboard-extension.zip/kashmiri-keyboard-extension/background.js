// Initialize extension state
chrome.runtime.onInstalled.addListener(function() {
    chrome.storage.sync.set({ isEnabled: false }, function() {
        console.log('Kashmiri Keyboard extension initialized with state: disabled');
        updateIcon(false);
    });
});

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log('Background received message:', request);
    
    if (request.action === 'updateIcon') {
        updateIcon(request.isEnabled);
        console.log('Icon updated to:', request.isEnabled ? 'ON (green)' : 'OFF (red)');
    }
    
    return true; // Keep the message channel open for async responses
});

// Update icon based on enabled/disabled state
function updateIcon(isEnabled) {
    try {
        // For testing, we'll use a color-based icon until proper icons are created
        const iconPath = isEnabled ? {
            16: 'images/icon16_on.png',
            48: 'images/icon48_on.png',
            128: 'images/icon128_on.png'
        } : {
            16: 'images/icon16_off.png',
            48: 'images/icon48_off.png',
            128: 'images/icon128_off.png'
        };
        
        chrome.action.setIcon({ path: iconPath });
        
        // Update badge
        chrome.action.setBadgeText({ text: isEnabled ? 'ON' : 'OFF' });
        chrome.action.setBadgeBackgroundColor({ 
            color: isEnabled ? '#10b981' : '#ef4444' 
        });
    } catch (error) {
        console.error('Error updating icon:', error);
    }
}

// Restore state when Chrome starts
chrome.runtime.onStartup.addListener(function() {
    chrome.storage.sync.get('isEnabled', function(data) {
        const isEnabled = data.isEnabled || false;
        console.log('Restoring extension state on startup:', isEnabled ? 'ON' : 'OFF');
        updateIcon(isEnabled);
    });
});
