# This PowerShell script packages the Kashmiri Anywhere Keyboard extension for distribution

$packageName = "kashmiri-anywhere-keyboard"
$version = (Get-Content -Raw -Path "manifest.json" | ConvertFrom-Json).version
$outputZip = "${packageName}-v${version}.zip"

# Create a temporary directory for packaging
$tempDir = "temp_package"
if (Test-Path $tempDir) {
    Remove-Item -Recurse -Force $tempDir
}
New-Item -ItemType Directory -Path $tempDir | Out-Null

# Copy all required files
Copy-Item -Path "manifest.json" -Destination $tempDir
Copy-Item -Path "popup.html" -Destination $tempDir
Copy-Item -Path "popup.css" -Destination $tempDir
Copy-Item -Path "popup.js" -Destination $tempDir
Copy-Item -Path "background.js" -Destination $tempDir
Copy-Item -Path "content.js" -Destination $tempDir
Copy-Item -Path "content.css" -Destination $tempDir
Copy-Item -Path "guide.html" -Destination $tempDir
Copy-Item -Path "images" -Destination $tempDir -Recurse

# Create the ZIP file
if (Test-Path $outputZip) {
    Remove-Item -Force $outputZip
}
Compress-Archive -Path "$tempDir\*" -DestinationPath $outputZip

# Clean up
Remove-Item -Recurse -Force $tempDir

Write-Host "Package created: $outputZip"
Write-Host "You can upload this file to the Chrome Web Store Developer Dashboard."
