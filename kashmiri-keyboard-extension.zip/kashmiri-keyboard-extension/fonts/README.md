## Kashmiri Keyboard Custom Fonts

This directory is for custom Kashmiri font files. Place your .ttf, .woff or .woff2 files here to make them available in the extension.

### How to use custom fonts:

1. Place your font file in this directory
2. Rename your main font file to `custom-font.ttf` (or .woff/.woff2)
3. In the extension's keyboard guide, select "Custom Font" from the font dropdown
4. The custom font will now be applied to all Kashmiri input fields

### Recommended Kashmiri Fonts:

- Noto Nastaliq Urdu (built-in)
- Jameel Noori Nastaleeq
- Alvi Nastaleeq
- Pak Nastaleeq
- Microsoft Uighur

Note: Make sure you have the right to use any font you add here.
