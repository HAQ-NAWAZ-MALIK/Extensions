# Kashmiri Anywhere Keyboard

A Chrome extension that enables typing in Kashmiri language anywhere on the web. With this extension, users can seamlessly switch between English and Kashmiri script without the need for any special software or website.

## Features

- Type in Kashmiri script in any text field on the web
- Toggle keyboard input on/off with a single click
- Use modifier keys (Shift/Alt) for alternate characters and diacritics
- Visual indicators for the extension state
- Toast notifications when toggling the keyboard
- Works on social media, email, documents, and more
- Lightweight and fast performance

## Installation

### From Chrome Web Store
*(Once published)*
1. Visit the [Kashmiri Anywhere Keyboard](https://chrome.google.com/webstore) in the Chrome Web Store
2. Click "Add to Chrome"
3. Confirm the installation

### Manual Installation (Developer Mode)
1. Download or clone this repository
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" (toggle in the top-right corner)
4. Click "Load unpacked" and select the extension folder
5. The extension should now appear in your toolbar

## How to Use

1. Click the extension icon in your browser toolbar
2. Toggle the "Enable Keyboard" button to turn on Kashmiri input
3. Start typing in any text field on the web
4. Use **Shift** or **Alt** as modifier keys for alternate characters
5. Toggle the extension off when you want to type in English

## Keyboard Layout

The extension uses a custom Kashmiri keyboard layout with the following features:

- Base characters are typed directly with normal keys
- Shift/Alt + key combinations produce alternate characters and diacritics
- The layout is designed to be intuitive for users familiar with English keyboards

For a complete layout reference, click "View Full Guide" in the extension popup.

## Troubleshooting

- **Extension Not Working**: Make sure it's enabled (green icon) and refresh the page
- **Characters Not Displaying**: Some websites might not support all Unicode characters
- **No Input**: Click inside the text field first before typing
- **Keyboard Shortcuts Not Working**: The extension respects common shortcuts (Ctrl+C, Ctrl+V, etc.)

## Contributors

- [Haq Nawaz Malik](https://haq-nawaz-malik.github.io/) (AI/ML)
- Nasir Ahmad Kumar (PHD in Kashmiri)
- Proff.Adil Ameen Kak (HOD Kashmiri Dept.)

## License

This project is open source and available under the MIT License.

---

Made with ❤️ by [HNM](https://haq-nawaz-malik.github.io/)
