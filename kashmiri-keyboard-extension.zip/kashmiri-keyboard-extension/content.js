// Kashmiri Character Mapping with Unicode
const kashCharMap = {
    '`': { normal: '\u0060', modifier: '\uFDFA' }, // `, ﷺ
    '1': { normal: '\u06F1', modifier: '\u0610' }, // ۱, ؐ
    '2': { normal: '\u06F2', modifier: '\u0613' }, // ۲, ؓ
    '3': { normal: '\u06F3', modifier: '\u0614' }, // ۳, ؔ
    '4': { normal: '\u06F4', modifier: '\u0603' }, // ۴, ؃
    '5': { normal: '\u06F5', modifier: '\u0612' }, // ۵, ؒ
    '6': { normal: '\u06F6', modifier: '\u0611' }, // ۶, ؑ
    '7': { normal: '\u06F7', modifier: '\u0652' }, // ۷, ْ
    '8': { normal: '\u06F8', modifier: '\u2018' }, // ۸, '
    '9': { normal: '\u06F9', modifier: '\u0028' }, // ۹, (
    '0': { normal: '\u0660', modifier: '\u0029' }, // ٠, )
    'Q': { normal: '\u0642', modifier: '\u064D' }, // ق, ٍ
    'W': { normal: '\u066E\u06EA', modifier: '\u0621' }, // ٮ۪, ء
    'E': { normal: '\u0639', modifier: '\u0670' }, // ع, ٰ
    'R': { normal: '\u0631', modifier: '\u0691' }, // ر, ڑ
    'T': { normal: '\u062A', modifier: '\u0679' }, // ت, ٹ
    'Y': { normal: '\u06D2', modifier: '\u0651' }, // ے, ّ
    'U': { normal: '\u0656', modifier: '\u0657' }, // ٖ, ٗ
    'I': { normal: '\u06CC', modifier: '\u06CD' }, // ی, ۍ
    'O': { normal: '\u06C1', modifier: '\u06BE' }, // ہ, ھ
    'P': { normal: '\u067E', modifier: '\u064F' }, // پ, ُ
    '[': { normal: '\u0637', modifier: '\u2019' }, // ط, '
    ']': { normal: '\u0638', modifier: '\u2018' }, // ظ, '
    'A': { normal: '\u0627', modifier: '\u0622' }, // ا, آ
    'S': { normal: '\u0633', modifier: '\u0635' }, // س, ص
    'D': { normal: '\u062F', modifier: '\u0688' }, // د, ڈ
    'F': { normal: '\u0641', modifier: '\u065A' }, // ف, ٚ
    'G': { normal: '\u062C', modifier: '\u063A' }, // ج, غ
    'H': { normal: '\u062D', modifier: '\u065B' }, // ح, ٛ
    'J': { normal: '\u062C', modifier: '\u0636' }, // ج, ض
    'K': { normal: '\u06A9', modifier: '\u062E' }, // ک, خ
    'L': { normal: '\u0644', modifier: '\u0631\u062D\u0645\u062A\u06C1\u0020\u0627\u0644\u0644\u06C1\u0020\u0639\u0644\u06CC\u06C1' }, // ل, رحمتہ الله عليه
    'Z': { normal: '\u0632', modifier: '\u0630' }, // ز, ذ
    'X': { normal: '\u0634', modifier: '\u0698' }, // ش, ژ
    'C': { normal: '\u0686', modifier: '\u062B' }, // چ, ث
    'V': { normal: '\u0648', modifier: '\u06C4' }, // و, ۄ
    'B': { normal: '\u0628', modifier: '\u064B' }, // ب, ً
    'N': { normal: '\u0646', modifier: '\u06BA' }, // ن, ں
    'M': { normal: '\u0645', modifier: '\u0655' }, // م, ٕ
    ',': { normal: '\u060C', modifier: '\u0650' }, // ،, ِ
    '.': { normal: '\u06D4', modifier: '\u064E' }, // ۔, َ
    '/': { normal: '\u0654', modifier: '\u061F' }, // ٔ, ؟
    '-': { normal: '\u0672', modifier: '\u06ED' },  // ٲ, ۭ
    ' ': { normal: ' ', modifier: ' ' }  // Space
};

// Physical Key to Virtual Key Mapping
const physicalMap = {
    // Normal characters
    '`': '`', '1': '1', '2': '2', '3': '3', '4': '4', '5': '5',
    '6': '6', '7': '7', '8': '8', '9': '9', '0': '0',
    // Shifted characters (what browser receives)
    '~': '`', '!': '1', '@': '2', '#': '3', '$': '4', '%': '5',
    '^': '6', '&': '7', '*': '8', '(': '9', ')': '0',
    // Punctuation
    ',': ',', '.': '.', '/': '/', '-': '-', '[': '[', ']': ']',
    '<': ',', '>': '.', '?': '/', '_': '-', '{': '[', '}': ']',
    '+': '=', '=': '=', ';': ';', ':': ';', "'": "'", '"': "'",
    '\\': '\\', '|': '\\',
    // Lowercase letters
    'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D', 'e': 'E', 'f': 'F', 'g': 'G',
    'h': 'H', 'i': 'I', 'j': 'J', 'k': 'K', 'l': 'L', 'm': 'M', 'n': 'N',
    'o': 'O', 'p': 'P', 'q': 'Q', 'r': 'R', 's': 'S', 't': 'T', 'u': 'U',
    'v': 'V', 'w': 'W', 'x': 'X', 'y': 'Y', 'z': 'Z',
    // Space
    ' ': ' '
};

// Extension state
let isEnabled = false;
let isShiftPressed = false;
let isAltPressed = false;
let activeElements = new Set();

// Initialize when the content script is loaded
init();

// Test mode for diagnosing issues - set to true to enable
const TEST_MODE = true;

// User settings with defaults
let userSettings = {
    fontSize: 16,
    fontFamily: 'Noto Nastaliq Urdu',
    isGuideVisible: false
};

function init() {
    chrome.storage.sync.get(['isEnabled', 'settings'], function(data) {
        isEnabled = data.isEnabled || false;
        console.log('Kashmiri Keyboard initialized with state:', isEnabled ? 'ON' : 'OFF');
        
        // Load user settings if available
        if (data.settings) {
            userSettings = {...userSettings, ...data.settings};
        }
        
        // Initialize CSS variables for font settings
        updateFontSettings();
        
        setupListeners();
        
        if (TEST_MODE) {
            injectTestConsole();
        }
        
        // Add keyboard guide
        injectKeyboardGuide();
        injectFontStylesheet();
    });
}

// Helper function to inject a test console for debugging
function injectTestConsole() {
    const testConsole = document.createElement('div');
    testConsole.id = 'kashmiri-test-console';
    testConsole.style.cssText = `
        position: fixed;
        bottom: 10px;
        right: 10px;
        width: 300px;
        max-height: 200px;
        overflow-y: auto;
        background: rgba(0, 0, 0, 0.8);
        color: #fff;
        padding: 10px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
        z-index: 99999;
        display: none;
    `;
    
    document.body.appendChild(testConsole);
    
    // Toggle test console with Ctrl+Alt+K
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.altKey && e.key === 'k') {
            testConsole.style.display = testConsole.style.display === 'none' ? 'block' : 'none';
        }
    });
}

// Log to test console
function testLog(message) {
    if (!TEST_MODE) return;
    
    const testConsole = document.getElementById('kashmiri-test-console');
    if (testConsole) {
        const logEntry = document.createElement('div');
        logEntry.textContent = message;
        logEntry.style.borderBottom = '1px solid rgba(255,255,255,0.2)';
        logEntry.style.padding = '4px 0';
        
        testConsole.appendChild(logEntry);
        testConsole.scrollTop = testConsole.scrollHeight;
        
        // Limit entries
        while (testConsole.children.length > 20) {
            testConsole.removeChild(testConsole.firstChild);
        }
    }
}

function setupListeners() {
    // Listen for state changes from the popup
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        console.log('Received message:', request);
        
        if (request.action === 'stateChanged') {
            isEnabled = request.isEnabled;
            console.log('Kashmiri Keyboard state changed to:', isEnabled ? 'ON' : 'OFF');
            
            // Show notification
            showNotification(
                isEnabled ? 'Kashmiri Keyboard Enabled' : 'Kashmiri Keyboard Disabled', 
                isEnabled ? 'success' : 'info'
            );
            
            // Update all active elements with class
            if (isEnabled) {
                addClassToEditableElements();
            } else {
                removeClassFromEditableElements();
            }
        }
        
        if (request.action === 'showNotification') {
            showNotification(request.text, request.type);
        }
    });

    // Track active element
    document.addEventListener('focusin', function(e) {
        if (isEditableElement(e.target)) {
            activeElements.add(e.target);
            if (isEnabled) {
                e.target.classList.add('kashmiri-input-active');
            }
        }
    }, true);
    
    document.addEventListener('focusout', function(e) {
        activeElements.delete(e.target);
        e.target.classList.remove('kashmiri-input-active');
    }, true);
    
    // Handle click events to better capture search bars
    document.addEventListener('click', function(e) {
        if (isEditableElement(e.target)) {
            activeElements.add(e.target);
            if (isEnabled) {
                e.target.classList.add('kashmiri-input-active');
            }
        }
    }, true);
    
    // Handle mutation events to detect dynamically added elements
    setupMutationObserver();

    // Key event listeners
    document.addEventListener('keydown', handleKeyDown, true);
    document.addEventListener('keyup', handleKeyUp, true);
    
    // Add initial classes
    if (isEnabled) {
        addClassToEditableElements();
    }
}

// Function to add our class to all editable elements
function addClassToEditableElements() {
    const inputs = document.querySelectorAll('input, textarea, [contenteditable="true"], [role="searchbox"]');
    inputs.forEach(input => {
        if (isEditableElement(input)) {
            input.classList.add('kashmiri-input-active');
        }
    });
}

// Function to remove our class from all elements
function removeClassFromEditableElements() {
    const inputs = document.querySelectorAll('.kashmiri-input-active');
    inputs.forEach(input => {
        input.classList.remove('kashmiri-input-active');
    });
}

// Setup mutation observer to handle dynamically added elements
function setupMutationObserver() {
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                mutation.addedNodes.forEach(function(node) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        // Check if the added node is an editable element
                        if (isEditableElement(node) && isEnabled) {
                            node.classList.add('kashmiri-input-active');
                        }
                        
                        // Check children of added node
                        const editableChildren = node.querySelectorAll('input, textarea, [contenteditable="true"], [role="searchbox"]');
                        editableChildren.forEach(child => {
                            if (isEditableElement(child) && isEnabled) {
                                child.classList.add('kashmiri-input-active');
                            }
                        });
                    }
                });
            }
        });
    });
    
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

function handleKeyDown(event) {
    if (!isEnabled) return;
    
    // Check if the active element is editable
    const activeElement = Array.from(activeElements).pop();
    if (!activeElement || !isEditableElement(activeElement)) return;
    
    // Handle modifier keys
    if (event.key === 'Shift') {
        isShiftPressed = true;
        testLog('SHIFT pressed');
        return;
    }
    
    if (event.key === 'Alt') {
        isAltPressed = true;
        testLog('ALT pressed');
        event.preventDefault(); // Prevent Alt from triggering browser menus
        return;
    }
    
    // Don't intercept keyboard shortcuts
    if ((event.ctrlKey || event.metaKey) && 
        ['c', 'v', 'x', 'a', 'z', 'y'].includes(event.key.toLowerCase())) {
        return;
    }
    
    // Handle backspace directly
    if (event.key === 'Backspace') {
        // Let the default behavior work
        return;
    }
    
    // Handle Enter key
    if (event.key === 'Enter') {
        // Let the default behavior work
        return;
    }
    
    // Get the mapping for the key
    const receivedKey = event.key;
    let mappedKey = getMappedKey(receivedKey);
    
    console.log('Key pressed:', receivedKey, 'Mapped to:', mappedKey);
    testLog(`Key: ${receivedKey} → Mapped: ${mappedKey}`);
    
    if (mappedKey && kashCharMap[mappedKey]) {
        // Determine if we should use modifier
        const useModifier = isShiftPressed || isAltPressed;
        const charData = kashCharMap[mappedKey];
        const char = useModifier && charData.modifier ? charData.modifier : charData.normal;
        
        console.log('Converting to:', char, 'useModifier:', useModifier);
        testLog(`Converting to: ${char} (${useModifier ? 'Modified' : 'Normal'})`);
        
        // Insert the character
        insertAtCursor(activeElement, char);
        
        // Prevent default to avoid double input
        event.preventDefault();
        event.stopPropagation();
    } else if (mappedKey === ' ') {
        // Handle space directly
        insertAtCursor(activeElement, ' ');
        testLog('Space inserted');
        event.preventDefault();
    }
}

function handleKeyUp(event) {
    if (!isEnabled) return;
    
    if (event.key === 'Shift') {
        isShiftPressed = false;
    }
    
    if (event.key === 'Alt') {
        isAltPressed = false;
    }
}

function getMappedKey(key) {
    // Map physical key to our virtual key
    if (physicalMap[key]) {
        return physicalMap[key];
    }
    
    // Handle alphabetic keys
    if (/^[a-zA-Z]$/.test(key)) {
        return key.toUpperCase();
    }
    
    // Handle space explicitly
    if (key === ' ') {
        return ' ';
    }
    
    console.log('No mapping found for key:', key);
    return null;
}

function isEditableElement(element) {
    if (!element) return false;
    
    const tagName = element.tagName.toLowerCase();
    const contentEditable = element.contentEditable === 'true';
    const role = element.getAttribute('role');
    const ariaRole = element.getAttribute('aria-role');
    
    // Enhanced detection for search bars and special input elements
    const isSpecialInput = role === 'searchbox' || 
                           ariaRole === 'searchbox' || 
                           element.getAttribute('aria-autocomplete') === 'list' ||
                           element.classList.contains('search-box') ||
                           element.classList.contains('searchbox') ||
                           element.classList.contains('search-input') ||
                           element.getAttribute('data-search') === 'true';
    
    return (
        (tagName === 'input' && 
         ['text', 'search', 'email', 'url', 'tel', 'number', 'password', ''].includes(element.type)) ||
        tagName === 'textarea' || 
        contentEditable || 
        isSpecialInput
    );
}

function insertAtCursor(element, text) {
    if (!element) return;
    
    try {
        if (element.tagName.toLowerCase() === 'input' || element.tagName.toLowerCase() === 'textarea') {
            const start = element.selectionStart;
            const end = element.selectionEnd;
            const value = element.value;
            
            element.value = value.substring(0, start) + text + value.substring(end);
            
            // Move cursor after inserted text
            element.selectionStart = element.selectionEnd = start + text.length;
            
            // Trigger input event for React/Vue/etc.
            triggerInputEvent(element);
            
            console.log('Inserted text in input/textarea:', text);
        } else if (element.contentEditable === 'true') {
            // Handle contentEditable elements
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                range.deleteContents();
                
                const textNode = document.createTextNode(text);
                range.insertNode(textNode);
                
                // Move cursor to end of inserted text
                range.setStartAfter(textNode);
                range.setEndAfter(textNode);
                selection.removeAllRanges();
                selection.addRange(range);
                
                // Trigger input event
                triggerInputEvent(element);
                
                console.log('Inserted text in contentEditable:', text);
            }
        }
    } catch (error) {
        console.error('Error inserting text:', error);
    }
}

function triggerInputEvent(element) {
    try {
        const inputEvent = new Event('input', {
            bubbles: true,
            cancelable: true,
        });
        
        element.dispatchEvent(inputEvent);
    } catch (error) {
        console.error('Error triggering input event:', error);
    }
}

// Debug function
function debugLog(message, data) {
    if (typeof data !== 'undefined') {
        console.log(`[Kashmiri Keyboard] ${message}`, data);
    } else {
        console.log(`[Kashmiri Keyboard] ${message}`);
    }
}

// Toast notification system
function showNotification(message, type = 'info') {
    // Remove any existing notification
    const existingNotification = document.getElementById('kashmiri-keyboard-notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.id = 'kashmiri-keyboard-notification';
    notification.className = `kashmiri-notification kashmiri-${type}`;
    
    // Add icon based on type
    let icon = '🔔';
    if (type === 'success') icon = '🍏';
    else if (type === 'error') icon = '🔴';
    else if (type === 'info') icon = '🔵';
    
    notification.innerHTML = `
        <span class="kashmiri-notification-icon">${icon}</span>
        <span class="kashmiri-notification-message">${message}</span>
    `;
    
    // Append to body
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Inject keyboard guide into the page
function injectKeyboardGuide() {
    // Create toggle button
    const toggleButton = document.createElement('button');
    toggleButton.className = 'kashmiri-guide-toggle';
    toggleButton.innerHTML = '⌨️';
    toggleButton.title = 'Show Kashmiri Keyboard Guide';
    document.body.appendChild(toggleButton);
    
    // Create guide container
    const guideContainer = document.createElement('div');
    guideContainer.className = 'kashmiri-keyboard-guide';
    guideContainer.id = 'kashmiri-keyboard-guide';
    
    // Create guide content
    guideContainer.innerHTML = `
        <div class="kashmiri-guide-header">
            <div class="kashmiri-guide-title">Kashmiri Keyboard Guide</div>
            <button class="kashmiri-guide-close">×</button>
        </div>
        
        <div class="kashmiri-guide-legend">
            <div class="kashmiri-legend-item">
                <div class="kashmiri-legend-dot kashmiri-dot-english"></div>
                <span>English Key</span>
            </div>
            <div class="kashmiri-legend-item">
                <div class="kashmiri-legend-dot kashmiri-dot-main"></div>
                <span>Normal Character</span>
            </div>
            <div class="kashmiri-legend-item">
                <div class="kashmiri-legend-dot kashmiri-dot-modifier"></div>
                <span>Shift/Alt Character</span>
            </div>
        </div>
        
        <div class="kashmiri-keyboard-rows" id="kashmiri-keyboard-layout">
            <!-- Keyboard layout will be generated here -->
        </div>
        
        <div class="kashmiri-font-controls">
            <h3>Font Settings</h3>
            <div>
                <label for="kashmiri-font-size">Font Size: <span id="kashmiri-font-size-value">${userSettings.fontSize}px</span></label>
                <input type="range" id="kashmiri-font-size" class="kashmiri-font-size-slider" min="12" max="32" value="${userSettings.fontSize}" step="1">
            </div>
            
            <div class="kashmiri-font-family">
                <label for="kashmiri-font-select">Font Family:</label>
                <select id="kashmiri-font-select">
                    <option value="Noto Nastaliq Urdu" ${userSettings.fontFamily === 'Noto Nastaliq Urdu' ? 'selected' : ''}>Noto Nastaliq Urdu</option>
                    <option value="custom" ${userSettings.fontFamily !== 'Noto Nastaliq Urdu' ? 'selected' : ''}>Custom Font</option>
                </select>
            </div>
        </div>
    `;
    
    document.body.appendChild(guideContainer);
    
    // Generate keyboard layout
    generateKeyboardLayout();
    
    // Setup event listeners
    toggleButton.addEventListener('click', () => {
        guideContainer.classList.toggle('show');
        userSettings.isGuideVisible = guideContainer.classList.contains('show');
        saveSettings();
    });
    
    guideContainer.querySelector('.kashmiri-guide-close').addEventListener('click', () => {
        guideContainer.classList.remove('show');
        userSettings.isGuideVisible = false;
        saveSettings();
    });
    
    // Font size slider
    const fontSizeSlider = document.getElementById('kashmiri-font-size');
    const fontSizeValue = document.getElementById('kashmiri-font-size-value');
    
    fontSizeSlider.addEventListener('input', (e) => {
        const newSize = e.target.value;
        fontSizeValue.textContent = `${newSize}px`;
        userSettings.fontSize = parseInt(newSize, 10);
        updateFontSettings();
    });
    
    fontSizeSlider.addEventListener('change', () => {
        saveSettings();
    });
    
    // Font family selector
    const fontSelect = document.getElementById('kashmiri-font-select');
    fontSelect.addEventListener('change', (e) => {
        userSettings.fontFamily = e.target.value;
        updateFontSettings();
        saveSettings();
    });
    
    // Show guide if it was previously visible
    if (userSettings.isGuideVisible) {
        guideContainer.classList.add('show');
    }
}

// Generate keyboard layout for the guide
function generateKeyboardLayout() {
    const container = document.getElementById('kashmiri-keyboard-layout');
    if (!container) return;
    
    container.innerHTML = '';
    
    // Keyboard Layout Definition (from existing code)
    const keyLayout = [
        ['`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '[', ']'],
        ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
        ['Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/'],
        ['-', 'SPACE']
    ];
    
    keyLayout.forEach(row => {
        const rowDiv = document.createElement('div');
        rowDiv.className = 'kashmiri-keyboard-row';
        
        row.forEach(keyId => {
            const keyElement = document.createElement('div');
            keyElement.className = keyId === 'SPACE' ? 'kashmiri-key kashmiri-spacebar' : 'kashmiri-key';
            
            if (keyId === 'SPACE') {
                keyElement.innerHTML = '<div class="kashmiri-key-main">Space</div>';
            } else if (kashCharMap[keyId]) {
                const charData = kashCharMap[keyId];
                keyElement.innerHTML = `
                    <div class="kashmiri-key-english">${keyId}</div>
                    <div class="kashmiri-key-main">${charData.normal}</div>
                    ${charData.modifier ? `<div class="kashmiri-key-modifier">${charData.modifier}</div>` : ''}
                `;
            }
            
            rowDiv.appendChild(keyElement);
        });
        
        container.appendChild(rowDiv);
    });
}

// Save user settings to storage
function saveSettings() {
    chrome.storage.sync.set({ settings: userSettings }, function() {
        console.log('Settings saved:', userSettings);
    });
}

// Update font settings in CSS variables
function updateFontSettings() {
    document.documentElement.style.setProperty('--kashmiri-font-size', `${userSettings.fontSize}px`);
    document.documentElement.style.setProperty('--kashmiri-font-family', userSettings.fontFamily);
}

// Inject a stylesheet for custom fonts
function injectFontStylesheet() {
    const style = document.createElement('style');
    style.id = 'kashmiri-font-stylesheet';
    style.textContent = `
        @font-face {
            font-family: 'KashmiriCustomFont';
            src: url(chrome-extension://${chrome.runtime.id}/fonts/custom-font.ttf) format('truetype');
            font-weight: normal;
            font-style: normal;
        }
        
        .kashmiri-input-active {
            font-family: var(--kashmiri-font-family, 'Noto Nastaliq Urdu'), serif !important;
            font-size: var(--kashmiri-font-size, inherit) !important;
        }
    `;
    
    document.head.appendChild(style);
}
