function applyFont(fontName, fontUrl) {
  const styleId = 'kashmiri-font-style';
  let style = document.getElementById(styleId);
  if (style) style.remove();
  style = document.createElement('style');
  style.id = styleId;
  style.textContent = `@font-face { font-family: '${fontName}'; src: url('${fontUrl}'); }\n  body, * { font-family: '${fontName}', sans-serif !important; }`;
  document.head.appendChild(style);
}

function removeFont() {
  const style = document.getElementById('kashmiri-font-style');
  if (style) style.remove();
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'APPLY_FONT') {
    const fontName = request.fontName;
    const fontUrl = request.fontUrl;
    if (!fontName || !fontUrl) {
      sendResponse({ success: false, error: 'Font name or URL missing.' });
      return;
    }
    applyFont(fontName, fontUrl);
    sendResponse({ success: true });
  } else if (request.type === 'REMOVE_FONT') {
    removeFont();
    sendResponse({ success: true });
  }
  return true;
});

// Bundled fonts mapping (must match popup.js)
const bundledFonts = [
  { name: 'Afan Koshur Naksh', file: 'Afan_Koshur_Naksh.ttf' },
  { name: 'Nastaleeq', file: 'Nastaleeq.ttf' },
  { name: 'Nakash (Narqalam)', file: 'Nakash (Narqalam).ttf' }
];

// On page load, check storage and apply font if needed
chrome.storage.sync.get(['kf_font', 'kf_scope', 'kf_enabled'], (data) => {
  if (data.kf_enabled === false) return; // extension off
  if (!data.kf_font) return;
  if (data.kf_scope === 'global' || data.kf_scope === undefined) {
    // Get proper font name from bundledFonts mapping
    const fontEntry = bundledFonts.find(f => f.file === data.kf_font);
    const fontName = fontEntry ? fontEntry.name : data.kf_font;
    const fontUrl = chrome.runtime.getURL('fonts/' + data.kf_font);
    applyFont(fontName, fontUrl);
  }
});