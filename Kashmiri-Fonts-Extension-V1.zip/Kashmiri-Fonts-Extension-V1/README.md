# Kashmiri Fonts Chrome Extension

Apply beautiful Kashmiri fonts to any webpage. Choose from bundled fonts or add your own!

## Features
- Select from multiple Kashmiri fonts (Nastaleek, Nakash, Afsana Kohur, etc.)
- Instantly apply the font to the whole webpage
- Add your own `.ttf` font files to the `fonts/` folder
- Modern, aesthetic popup UI
- Error handling for font loading

## How to Use
1. Click the Kashmiri Fonts extension icon.
2. Choose a font from the dropdown.
3. Preview the font.
4. Click "Apply Font" to apply it to the current page.

## Adding More Fonts
- Place any `.ttf` font files in the `fonts/` folder.
- The extension will automatically list them for selection (if added to the `bundledFonts` array in `popup.js`).

## Font Sources
- Bundled fonts are from the [HAQ-NAWAZ-MALIK/Kashmiri_fonts GitHub repo](https://github.com/HAQ-NAWAZ-MALIK/Kashmiri_fonts).
- Please respect font licenses if redistributing.

## Credits
- [HAQ-NAWAZ-MALIK/Kashmiri_fonts](https://github.com/HAQ-NAWAZ-MALIK/Kashmiri_fonts) for font collection.

## License
MIT (or as per your preference) 